import 'dart:convert';

class api {
  //Future<List> getdata()async{
  // String ServerUrl="";
  //http.Respnse response= await http.get(ServerUrl,
  //     headers:{
  //'accept':'',
  //'authorization':'bearer $token'
  //     });
  //return json.decode(response.body);
  // }

  //_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-

  // void addData(){
  // String ServerUrl="";
  //http.post(ServerUrl,
  //     headers:{
  //'accept':'',
  //'authorization':'bearer $token'
  //     },
  //body:{
  //the body of the api keys and values
  //}).then((response){
  // print('response status :${response.statusCode}');
  // print('response body :${response.body}');
  // }
  // );
  // }
  //_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-

  // void editData(){
  //int id=0;
  // String ServerUrl="/$id";
  //http.put(ServerUrl,
  //     headers:{
  //'accept':'',
  //'authorization':'bearer $token'
  //     },
  //body:{
  //the body of the api keys and values
  //}).then((response){
  // print('response status :${response.statusCode}');
  // print('response body :${response.body}');
  // }
  // );
  // }

  //_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-
  // void deleteData(){
  //int id=0;
  // String ServerUrl="/$id";
  //http.delete(ServerUrl,
  //     headers:{
  //'accept':'',
  //'authorization':'bearer $token'
  //     }).then((response){
  // print('response status :${response.statusCode}');
  // print('response body :${response.body}');
  // }
  // );
  // }

  //_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-

  // void login(){
  // String ServerUrl="";
  //http.post(ServerUrl,
  //     headers:{
  //'accept':'',
  //     },
  //body:{
  //the body of the api keys and values
  //}).then((response){
  // print('response status :${response.statusCode}');
  // print('response body :${response.body}');
  //Map mapValue=json.decode(response.body);
  //var tokenValue=mapValue.values.toString();
  // }
  // );
  // }

  //_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-

  // void register(){
  // String ServerUrl="";
  //http.post(ServerUrl,
  //     headers:{
  //'accept':'',
  //     },
  //body:{
  //the body of the api keys and values
  //}).then((response){
  // print('response status :${response.statusCode}');
  // print('response body :${response.body}');
  //Map mapValue=json.decode(response.body);
  //var tokenValue=mapValue.values.toString();
  // }
  // );
  //the different between login and register is in url and body
  // }

  //_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-

}
