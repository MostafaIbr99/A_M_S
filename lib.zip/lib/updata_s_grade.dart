
import 'package:flutter/material.dart';

class StudentGrade extends StatefulWidget {
  @override
  _StudentGradeState createState() => _StudentGradeState();
}

class _StudentGradeState extends State<StudentGrade> {
  @override
  var s = {
    'name': 'mostafa ibrahim',
    'program': 'computer scince',
    'level': '4',
    'id': '145123',
  };

  var courses = [
    {
      'code': 'comp401',
      'degre': 0,
    },
    {
      'code': 'comp403',
      'degre': 0,
    },
    {
      'code': 'comp405',
      'degre': 0,
    },
    {
      'code': 'comp407',
      'degre': 0,
    },
    {
      'code': 'comp409',
      'degre': 0,
    },
    {
      'code': 'comp411',
      'degre': 0,
    },
    {
      'code': 'comp415',
      'degre': 0,
    },
  ];

  Widget lis(index) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Text(
          courses[index]['code'],
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        Material(
          child: Container(
            height: 45,
            width: 120,
            child: TextFormField(
              decoration: InputDecoration(
                  border: OutlineInputBorder(
                borderSide: BorderSide(width: 1),
              )),
              keyboardType: TextInputType.number,
              initialValue: courses[index]['degre'].toString(),
            ),
          ),
        ),
      ],
    );
  }

  String imgURL = 'gjn';
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(
            height: 50,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Image.asset(
                'src/ulogo.jpg',
                width: 70,
                height: 70,
              ),
              Text(
                'update student degree',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              Image.asset(
                'src/flogo.jpg',
                width: 80,
                height: 70,
              ),
            ],
          ),
          ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(imgURL),
              radius: 30.0,
            ),
            title: Column(
              children: [
                Row(
                  children: [
                    Text('student name :'),
                    Text(s['name']),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Text('program:'),
                    Text(s['program']),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Text('level :'),
                    Text(s['level']),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Text('acadmic id :'),
                    Text(s['id']),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(
            height: 35,
          ),
          for (int i = 0; i < courses.length; i++) lis(i),
          Padding(
            padding: const EdgeInsets.fromLTRB(14.0, 8.0, 14.0, 8.0),
            child: Material(
                borderRadius: BorderRadius.circular(20.0),
                color: Colors.blue.shade700,
                elevation: 0.0,
                child: MaterialButton(
                  onPressed: () {},
                  minWidth: MediaQuery.of(context).size.width,
                  child: Text(
                    "update",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 20.0),
                  ),
                )),
          ),
        ],
      ),
    ));
  }
}
