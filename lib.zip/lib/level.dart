import 'package:flutter/material.dart';

import 'chat.dart';
class ChatLevels extends StatefulWidget {
  @override
  _ChatLevelsState createState() => _ChatLevelsState();
}

class _ChatLevelsState extends State<ChatLevels> {
  @override
  Widget build(BuildContext context) {
    return Material(
      child: Column(
        children: [
          SizedBox(
            height: 50,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Image.asset(
                'src/ulogo.jpg',
                width: 50,
                height: 70,
              ),
              Text(
                'automatic advice for semest',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              Image.asset(
                'src/flogo.jpg',
                width: 60,
                height: 70,
              ),
            ],
          ),

          ListTile(
            title: Text('Level  1'),
            subtitle: Text('number of student 6'),
           onTap: (){
             Navigator.push(context,
                 MaterialPageRoute(builder: (context) => ChatList()));
           },
          ),
          ListTile(
            title: Text('Level  2'),
            subtitle: Text('number of student 6'),
            onTap: (){
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ChatList()));
            },
          ),
          ListTile(
            title: Text('Level  3'),
            subtitle: Text('number of student 6'),
            onTap: (){
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ChatList()));
            },

          ),
          ListTile(
            title: Text('Level  4'),
            subtitle: Text('number of student 6'),
            onTap: (){
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => ChatList()));
            },

          ),

        ],
      ),
    );
  }
}

