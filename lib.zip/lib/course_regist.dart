import 'package:flutter/material.dart';

class RegistPage extends StatefulWidget {
  @override
  _RegistPageState createState() => _RegistPageState();
}

//_-_-_-_-_-_-_-_-_-_-_-####################
//_-_-_-_-_-_-_-_-_-_-_-####################

class _RegistPageState extends State<RegistPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Padding(
            padding: const EdgeInsets.only(top: 50),
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Image.asset(
                        'src/ulogo.jpg',
                        width: 70,
                        height: 70,
                      ),
                      Image.asset(
                        'src/flogo.jpg',
                        width: 80,
                        height: 70,
                      ),
                    ],
                  ),
                  Text(
                    'نمودج حدف واضافه',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  ),
                  trow.row(
                    'المستوى',
                    'الاسم باللغه العربيه',
                  ),
                  trow.row('التخصص', 'الاسم بالانجليزيه'),
                  trow.row('المعدل التراكمى', 'الجنسيه'),
                  trow.row('المرشد الاكاديمى', 'الرقم القومى'),
                  trow.row('الهاتف الارضى', 'الرقم الاكاديمي'),
                  trow.row(' ', 'رقم الموبايل'),
                  SizedBox(
                    height: 40,
                  ),
                  Table(
                    border: TableBorder.all(color: Colors.black),
                    children: [
                      TableRow(children: [
                        Center(
                          child: Text(
                            'المقررات المراد اضافتها',
                            style: TextStyle(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                        )
                      ])
                    ],
                  ),
                  Table(
                    border: TableBorder.all(color: Colors.black),
                    children: [
                      TableRow(children: [
                        Center(
                          child: Text(
                            'عدد الوحدات',
                            style: TextStyle(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Center(
                          child: Text(
                            'متطلب سابق',
                            style: TextStyle(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Center(
                          child: Text(
                            'اسم المقرر',
                            style: TextStyle(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                        ),
                        Center(
                          child: Text(
                            'كود المقرر',
                            style: TextStyle(
                                fontSize: 15, fontWeight: FontWeight.bold),
                          ),
                        )
                      ])
                    ],
                  ),
                  trow.f(),
                  trow.f(),
                  trow.f(),
                  trow.f(),
                  trow.f(),
                  trow.f(),
                  trow.f(),
                  trow.f(),
                  trow.f(),
                  trow.f(),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Form(
                          child: Container(
                              width: 70,
                              child: TextFormField(
                                decoration: InputDecoration(
                                  hintText: 'مجموع الوحدات',
                                  hintStyle: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold),
                                ),
                              )))
                    ],
                  ),
                ],
              ),
            )));
  }
}

//_-_-_-_-_-_-_-_-_-_-_-####################
//_-_-_-_-_-_-_-_-_-_-_-####################

class trow extends StatelessWidget {
  static Widget f() {
    return Table(border: TableBorder.all(color: Colors.black), children: [
      TableRow(children: [
        Container(
          height: 30,
          child: Material(
            borderRadius: BorderRadius.circular(0.0),
            color: Colors.white.withOpacity(0.4),
            elevation: 0.0,
            child: Padding(
              padding: const EdgeInsets.only(right: 0.0),
              child: TextFormField(
                decoration: InputDecoration(),
              ),
            ),
          ),
        ),
        Container(
          height: 30,
          child: Material(
            borderRadius: BorderRadius.circular(0.0),
            color: Colors.white.withOpacity(0.4),
            elevation: 0.0,
            child: Padding(
              padding: const EdgeInsets.only(right: 0.0),
              child: TextFormField(
                decoration: InputDecoration(),
              ),
            ),
          ),
        ),
        Container(
          height: 30,
          child: Material(
            borderRadius: BorderRadius.circular(0.0),
            color: Colors.white.withOpacity(0.4),
            elevation: 0.0,
            child: Padding(
              padding: const EdgeInsets.only(right: 0.0),
              child: TextFormField(
                decoration: InputDecoration(),
              ),
            ),
          ),
        ),
        Container(
          height: 30,
          width: 50,
          child: Container(
            child: Material(
              borderRadius: BorderRadius.circular(0.0),
              color: Colors.white.withOpacity(0.4),
              elevation: 0.0,
              child: Padding(
                padding: const EdgeInsets.only(right: 0.0),
                child: TextFormField(
                  decoration: InputDecoration(),
                ),
              ),
            ),
          ),
        ),
      ]),
    ]);
  }

  String hint1, hint2;

  static Widget row(
    hint1,
    hint2,
  ) {
    return Table(border: TableBorder.all(color: Colors.black), children: [
      TableRow(children: [
        Container(
          height: 30,
          child: Material(
            borderRadius: BorderRadius.circular(0.0),
            color: Colors.white.withOpacity(0.4),
            elevation: 0.0,
            child: Padding(
              padding: const EdgeInsets.only(right: 0.0),
              child: TextFormField(
                // controller: input1,
                decoration: InputDecoration(
                  hintText: hint1,
                  hintStyle:
                      TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ),
        Container(
          height: 30,
          child: Material(
            borderRadius: BorderRadius.circular(0.0),
            color: Colors.white.withOpacity(0.4),
            elevation: 0.0,
            child: Padding(
              padding: const EdgeInsets.only(right: 0.0),
              child: TextFormField(
                //  controller: input2,
                decoration: InputDecoration(
                  hintText: hint2,
                  hintStyle:
                      TextStyle(fontSize: 10, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ),
      ]),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
