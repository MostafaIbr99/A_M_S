import 'package:flutter/material.dart';

class AdviseAll extends StatefulWidget {
  @override
  _AdviseAllState createState() => _AdviseAllState();
}

class _AdviseAllState extends State<AdviseAll> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        leading: Image.asset(
          'src/ulogo.jpg',
          width: 50,
          height: 70,
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'automatic advice for all years',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            Image.asset(
              'src/flogo.jpg',
              width: 60,
              height: 70,
            ),
          ],
        ),
      ),
      body: ListView.builder(
          itemCount: adivces_all.length,
          itemBuilder: (context, index) {
            return Column(
              children: [
                SizedBox(
                  height: 50,
                ),
                Table(border: TableBorder.all(color: Colors.black), children: [
                  TableRow(
                    children: [
                      Container(
                        color: Colors.black,
                        child: Center(
                            child: Text(
                          'course code :',
                          style: TextStyle(
                            fontSize: 25,
                            color: Colors.white,
                          ),
                        )),
                      ),
                      Container(
                        color: Colors.black,
                        child: Center(
                            child: Text(
                          'course hours :',
                          style: TextStyle(
                            fontSize: 25,
                            color: Colors.white,
                          ),
                        )),
                      ),
                    ],
                  ),
                ]),
                for (int i = 0; i < adivces_all[index].length; i++)
                  Table(
                      border: TableBorder.all(color: Colors.black),
                      children: [
                        TableRow(
                          children: [
                            Center(
                                child: Text(
                              adivces_all[index][i]['code'],
                              style: TextStyle(
                                fontSize: 25,
                              ),
                            )),
                            Center(
                                child: Text(
                              adivces_all[index][i]['hours'],
                              style: TextStyle(
                                fontSize: 25,
                              ),
                            )),
                          ],
                        ),
                      ]),
                Table(
                  border: TableBorder.all(color: Colors.black),
                  children: [
                    TableRow(
                      children: [
                        Center(
                            child: Text(
                          'TCH',
                          style: TextStyle(
                            fontSize: 25,
                          ),
                        )),
                        Center(
                            child: Text(
                          '17',
                          style: TextStyle(
                            fontSize: 25,
                          ),
                        )),
                      ],
                    ),
                  ],
                ),
              ],
            );
          }),
    );
  }

  List<List<Map<String, String>>> adivces_all = [
    [
      {
        'code': 'comp401',
        'hours': '3',
      },
      {
        'code': 'comp403',
        'hours': '3',
      },
      {
        'code': 'comp405',
        'hours': '2',
      },
      {
        'code': 'comp407',
        'hours': '3',
      },
      {
        'code': 'comp409',
        'hours': '1',
      },
      {
        'code': 'comp411',
        'hours': '2',
      },
      {
        'code': 'comp415',
        'hours': '3',
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
      },
      {
        'code': 'comp403',
        'hours': '3',
      },
      {
        'code': 'comp405',
        'hours': '2',
      },
      {
        'code': 'comp407',
        'hours': '3',
      },
      {
        'code': 'comp409',
        'hours': '1',
      },
      {
        'code': 'comp411',
        'hours': '2',
      },
      {
        'code': 'comp415',
        'hours': '3',
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
      },
      {
        'code': 'comp403',
        'hours': '3',
      },
      {
        'code': 'comp405',
        'hours': '2',
      },
      {
        'code': 'comp407',
        'hours': '3',
      },
      {
        'code': 'comp409',
        'hours': '1',
      },
      {
        'code': 'comp411',
        'hours': '2',
      },
      {
        'code': 'comp415',
        'hours': '3',
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
      },
      {
        'code': 'comp403',
        'hours': '3',
      },
      {
        'code': 'comp405',
        'hours': '2',
      },
      {
        'code': 'comp407',
        'hours': '3',
      },
      {
        'code': 'comp409',
        'hours': '1',
      },
      {
        'code': 'comp411',
        'hours': '2',
      },
      {
        'code': 'comp415',
        'hours': '3',
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
      },
      {
        'code': 'comp403',
        'hours': '3',
      },
      {
        'code': 'comp405',
        'hours': '2',
      },
      {
        'code': 'comp407',
        'hours': '3',
      },
      {
        'code': 'comp409',
        'hours': '1',
      },
      {
        'code': 'comp411',
        'hours': '2',
      },
      {
        'code': 'comp415',
        'hours': '3',
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
      },
      {
        'code': 'comp403',
        'hours': '3',
      },
      {
        'code': 'comp405',
        'hours': '2',
      },
      {
        'code': 'comp407',
        'hours': '3',
      },
      {
        'code': 'comp409',
        'hours': '1',
      },
      {
        'code': 'comp411',
        'hours': '2',
      },
      {
        'code': 'comp415',
        'hours': '3',
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
      },
      {
        'code': 'comp403',
        'hours': '3',
      },
      {
        'code': 'comp405',
        'hours': '2',
      },
      {
        'code': 'comp407',
        'hours': '3',
      },
      {
        'code': 'comp409',
        'hours': '1',
      },
      {
        'code': 'comp411',
        'hours': '2',
      },
      {
        'code': 'comp415',
        'hours': '3',
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
      },
      {
        'code': 'comp403',
        'hours': '3',
      },
      {
        'code': 'comp405',
        'hours': '2',
      },
      {
        'code': 'comp407',
        'hours': '3',
      },
      {
        'code': 'comp409',
        'hours': '1',
      },
      {
        'code': 'comp411',
        'hours': '2',
      },
      {
        'code': 'comp415',
        'hours': '3',
      },
    ],
  ];
}
