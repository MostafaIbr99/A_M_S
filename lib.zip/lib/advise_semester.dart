import 'package:flutter/material.dart';

class AdviseSemester extends StatefulWidget {
  @override
  _AdviseSemesterState createState() => _AdviseSemesterState();
}

class _AdviseSemesterState extends State<AdviseSemester> {
  @override
  List adivces = [
    {
      'code': 'comp401',
      'hours': '3',
    },
    {
      'code': 'comp403',
      'hours': '3',
    },
    {
      'code': 'comp405',
      'hours': '2',
    },
    {
      'code': 'comp407',
      'hours': '3',
    },
    {
      'code': 'comp409',
      'hours': '1',
    },
    {
      'code': 'comp411',
      'hours': '2',
    },
    {
      'code': 'comp415',
      'hours': '3',
    },
  ];

  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 50,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Image.asset(
                  'src/ulogo.jpg',
                  width: 50,
                  height: 70,
                ),
                Text(
                  'automatic advice for semest',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                ),
                Image.asset(
                  'src/flogo.jpg',
                  width: 60,
                  height: 70,
                ),
              ],
            ),
            SizedBox(
              height: 50,
            ),
            Table(border: TableBorder.all(color: Colors.black), children: [
              TableRow(
                children: [
                  Container(
                    color: Colors.black,
                    child: Center(
                        child: Text(
                      'course code :',
                      style: TextStyle(
                        fontSize: 25,
                        color: Colors.white,
                      ),
                    )),
                  ),
                  Container(
                    color: Colors.black,
                    child: Center(
                        child: Text(
                      'course hours :',
                      style: TextStyle(
                        fontSize: 25,
                        color: Colors.white,
                      ),
                    )),
                  ),
                ],
              ),
            ]),
            for (int i = 0; i < adivces.length; i++)
              Table(border: TableBorder.all(color: Colors.black), children: [
                TableRow(
                  children: [
                    Center(
                        child: Text(
                      adivces[i]['code'],
                      style: TextStyle(
                        fontSize: 25,
                      ),
                    )),
                    Center(
                        child: Text(
                      adivces[i]['hours'],
                      style: TextStyle(
                        fontSize: 25,
                      ),
                    )),
                  ],
                ),
              ]),
            Table(border: TableBorder.all(color: Colors.black), children: [
              TableRow(
                children: [
                  Center(
                      child: Text(
                    'TCH',
                    style: TextStyle(
                      fontSize: 25,
                    ),
                  )),
                  Center(
                      child: Text(
                    '17',
                    style: TextStyle(
                      fontSize: 25,
                    ),
                  )),
                ],
              ),
            ]),
          ],
        ),
      ),
    );
  }
}
