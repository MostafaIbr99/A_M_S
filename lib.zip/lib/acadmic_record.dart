
import 'package:flutter/material.dart';

class Record extends StatefulWidget {

  @override
  _RecordState createState() => _RecordState();
}

var semest = 'fail';

class _RecordState extends State<Record> {
  var s = {
    'name': 'mostafa ibrahim',
    'program': 'computer scince',
    'level': '4',
    'id': '145123',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        leading: Image.asset(
          'src/ulogo.jpg',
          width: 50,
          height: 70,
        ),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'acadmc record',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            Image.asset(
              'src/flogo.jpg',
              width: 60,
              height: 70,
            ),
          ],
        ),
      ),
      body: ListView.builder(
          itemCount: record.length,
          itemBuilder: (context, index) {
            if (index % 2 == 0)
              semest = 'spring';
            else
              semest = 'fail';
            return Column(
              children: [
                SizedBox(
                  height: 50,
                ),
                if (index == 0)
                  ListTile(
                    leading: CircleAvatar(

                      radius: 30.0,
                    ),
                    title: Column(
                      children: [
                        Row(
                          children: [
                            Text('student name :'),
                            Text(s['name']),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            Text('program:'),
                            Text(s['program']),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            Text('level :'),
                            Text(s['level']),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          children: [
                            Text('acadmic id :'),
                            Text(s['id']),
                          ],
                        ),
                      ],
                    ),
                  ),
                SizedBox(
                  height: 50,
                ),
                Row(
                  children: [
                    Container(
                      child: Center(
                          child: Text(
                        semest,
                        style: TextStyle(
                          fontSize: 15,
                        ),
                      )),
                    ),
                    Container(
                      child: Center(
                          child: Text(
                        ' 2017/2018',
                        style: TextStyle(
                          fontSize: 15,
                        ),
                      )),
                    ),
                  ],
                ),
                Table(border: TableBorder.all(color: Colors.black), children: [
                  TableRow(
                    children: [
                      Container(
                        color: Colors.black,
                        child: Center(
                            child: Text(
                          ' code :',
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                          ),
                        )),
                      ),
                      Container(
                        color: Colors.black,
                        child: Center(
                            child: Text(
                          ' hours :',
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                          ),
                        )),
                      ),
                      Container(
                        color: Colors.black,
                        child: Center(
                            child: Text(
                          ' gl :',
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                          ),
                        )),
                      ),
                      Container(
                        color: Colors.black,
                        child: Center(
                            child: Text(
                          ' point :',
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                          ),
                        )),
                      ),
                      Container(
                        color: Colors.black,
                        child: Center(
                            child: Text(
                          ' degree :',
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.white,
                          ),
                        )),
                      ),
                    ],
                  ),
                ]),
                for (int i = 0; i < record[index].length; i++)
                  Table(
                      border: TableBorder.all(color: Colors.black),
                      children: [
                        TableRow(
                          children: [
                            Center(
                                child: Text(
                              record[index][i]['code'],
                              style: TextStyle(
                                fontSize: 15,
                              ),
                            )),
                            Center(
                                child: Text(
                              record[index][i]['hours'],
                              style: TextStyle(
                                fontSize: 15,
                              ),
                            )),
                            Center(
                                child: Text(
                              record[index][i]['gl'],
                              style: TextStyle(
                                fontSize: 15,
                              ),
                            )),
                            Center(
                                child: Text(
                              record[index][i]['point'],
                              style: TextStyle(
                                fontSize: 15,
                              ),
                            )),
                            Center(
                                child: Text(
                              record[index][i]['degree'],
                              style: TextStyle(
                                fontSize: 15,
                              ),
                            )),
                          ],
                        ),
                      ]),
                Table(
                  border: TableBorder.all(color: Colors.black),
                  children: [
                    TableRow(
                      children: [
                        Center(
                            child: Text(
                          'avarge point',
                          style: TextStyle(
                            fontSize: 15,
                          ),
                        )),
                        Center(
                            child: Text(
                          '3',
                          style: TextStyle(
                            fontSize: 15,
                          ),
                        )),
                        Center(
                            child: Text(
                          'gl',
                          style: TextStyle(
                            fontSize: 15,
                          ),
                        )),
                        Center(
                            child: Text(
                          'B',
                          style: TextStyle(
                            fontSize: 15,
                          ),
                        )),
                      ],
                    ),
                  ],
                ),
              ],
            );
          }),
    );
  }

  List<List<Map<String, String>>> record = [
    [
      {
        'code': 'comp401',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp403',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp405',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp407',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp409',
        'hours': '1',
        'point': '3',
        'degree': '38.5',
        'gl': 'B'
      },
      {
        'code': 'comp411',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp415',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp403',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp405',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp407',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp409',
        'hours': '1',
        'point': '3',
        'degree': '38.5',
        'gl': 'B'
      },
      {
        'code': 'comp411',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp415',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp403',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp405',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp407',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp409',
        'hours': '1',
        'point': '3',
        'degree': '38.5',
        'gl': 'B'
      },
      {
        'code': 'comp411',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp415',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp403',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp405',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp407',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp409',
        'hours': '1',
        'point': '3',
        'degree': '38.5',
        'gl': 'B'
      },
      {
        'code': 'comp411',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp415',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp403',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp405',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp407',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp409',
        'hours': '1',
        'point': '3',
        'degree': '38.5',
        'gl': 'B'
      },
      {
        'code': 'comp411',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp415',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp403',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp405',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp407',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp409',
        'hours': '1',
        'point': '3',
        'degree': '38.5',
        'gl': 'B'
      },
      {
        'code': 'comp411',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp415',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
    ],
    [
      {
        'code': 'comp401',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp403',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp405',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp407',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
      {
        'code': 'comp409',
        'hours': '1',
        'point': '3',
        'degree': '38.5',
        'gl': 'B'
      },
      {
        'code': 'comp411',
        'hours': '2',
        'point': '3',
        'degree': '75',
        'gl': 'B'
      },
      {
        'code': 'comp415',
        'hours': '3',
        'point': '3',
        'degree': '150',
        'gl': 'B'
      },
    ],
  ];
}
