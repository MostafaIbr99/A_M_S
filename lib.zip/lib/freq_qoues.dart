import 'package:fashion/login.dart';
import 'package:fashion/qoestion.dart';
import 'package:flutter/material.dart';

class QuestionShow extends StatefulWidget {
  @override
  _QuestionShowState createState() => _QuestionShowState();
}

class _QuestionShowState extends State<QuestionShow> {
 Question x=Question('title1', 'body1', 'answer1', 'dept', 'doctor1');

 Question y=Question('title2', 'body2', 'answer2', 'dept', 'doctor2');

 Question z=Question('title3', 'body3', 'answer3', 'dept', 'doctor3');

 Question a=Question('title4', 'body4', 'answer4', 'dept', 'doctor4');

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Column(
        children: [
          SizedBox(
            height: 50,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Image.asset(
                'src/ulogo.jpg',
                width: 50,
                height: 70,
              ),
              Text(
                'automatic advice for semest',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
              ),
              Image.asset(
                'src/flogo.jpg',
                width: 60,
                height: 70,
              ),
            ],
          ),

          ListTile(
            title: Text(x.body),
            subtitle: Text(x.answer),
            trailing: Text(x.doctor),

          ),
          ListTile(
            title: Text(y.body),
            subtitle: Text(y.answer),
            trailing: Text(y.doctor),

          ),
          ListTile(
            title: Text(z.body),
            subtitle: Text(z.answer),
            trailing: Text(z.doctor),

          ),
          ListTile(
            title: Text(a.body),
            subtitle: Text(a.answer),
            trailing: Text(a.doctor),

          ),

        ],
      ),
    );
  }
}
