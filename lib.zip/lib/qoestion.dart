class Question{
  var title,body,answer,dept,doctor;
  Question(this.title,this.body,this.answer,this.dept,this.doctor);
}