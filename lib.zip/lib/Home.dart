//import 'package:fashion/users.dart';
import 'package:flutter/material.dart';
import 'package:fashion/Smid.dart';
import 'package:fashion/advise_semester.dart';
import 'package:fashion/course_regist.dart';
import 'package:fashion/creates.dart';
import 'package:fashion/freq_qoues.dart';
import 'package:fashion/level.dart';
import 'package:fashion/questoin_post.dart';
import 'package:fashion/ui/screens/chat.dart';
import 'package:fashion/updata_s_grade.dart';
import 'acadmic_record.dart';
import 'main.dart';
class Home extends StatefulWidget {

 user u;
  Home(this.u);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  TextEditingController _StudentNameTextController = TextEditingController();

  var s={
    'name':'mostafa ibrahim',
    'program':'computer science',
    'level':'4',
    'id':'1233546',
  };


  @override
  Widget build(BuildContext context) {
    if(widget.u.type=='student')
    return Material(
      child: Container(
        color: Colors.white,
        child: Column(
          children: [
            SizedBox(height: 50,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Image.asset(
                  'src/ulogo.jpg',
                  width: 50,
                  height: 70,
                ),
                Text(
                  'automatic advice for semest',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                ),
                Image.asset(
                  'src/flogo.jpg',
                  width: 60,
                  height: 70,
                ),
              ],
            ),
            ListTile(
              leading: CircleAvatar(

                radius: 30.0,
              ),
              title: Column(
                children: [
                  Row(
                    children: [
                      Text('student name :'),
                      Text(s['name']),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Text('program:'),
                      Text(s['program']),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Text('level :'),
                      Text(s['level']),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Text('acadmic id :'),
                      Text(s['id']),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              child: GridView(
                gridDelegate:SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 200,
                  childAspectRatio: 3/2,
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 20,
                ),


                children: [
                  Material(
                    borderRadius: BorderRadius.circular(15.0),
                    color: Colors.redAccent,
                    child: MaterialButton(
                      elevation: 0.0,


                        onPressed: (){
                          Navigator.push(context,
                              MaterialPageRoute(builder: (context) => AdviseSemester()));
                        },
                        child: Text('advise for semester')
                    ),
                  ),

                  Material(
                    borderRadius: BorderRadius.circular(15.0),
                    color: Colors.redAccent,
                    child: MaterialButton(
                        elevation: 0.0,


                        onPressed: (){
                          Navigator.push(context,
                              MaterialPageRoute(builder: (context) => QuestionShow()));
                        },
                        child: Text('Most frequently question')
                    ),
                  ),
                  Material(
                    borderRadius: BorderRadius.circular(15.0),
                    color: Colors.redAccent,
                    child: MaterialButton(
                        elevation: 0.0,


                        onPressed: (){
                          Navigator.push(context,
                              MaterialPageRoute(builder: (context) => AdviseSemester()));
                        },
                        child: Text('advise for semester')
                    ),
                  ),

                  Material(
                    borderRadius: BorderRadius.circular(15.0),
                    color: Colors.redAccent,
                    child: MaterialButton(
                        elevation: 0.0,


                        onPressed: (){
                          Navigator.push(context,
                              MaterialPageRoute(builder: (context) => RegistPage()));
                        },
                        child: Text('courses registration')
                    ),
                  ),

                  Material(
                    borderRadius: BorderRadius.circular(15.0),
                    color: Colors.redAccent,
                    child: MaterialButton(
                        elevation: 0.0,


                        onPressed: (){
                          Navigator.push(context,
                              MaterialPageRoute(builder: (context) => Record()));
                        },
                        child: Text('my academic record')
                    ),
                  ),

                  Material(
                    borderRadius: BorderRadius.circular(15.0),
                    color: Colors.redAccent,
                    child: MaterialButton(
                        elevation: 0.0,


                        onPressed: (){
                          Navigator.push(context,
                              MaterialPageRoute(builder: (context) => MidDgree(3)));
                        },
                        child: Text('my midterm degree')
                    ),
                  ),

                  Material(
                    borderRadius: BorderRadius.circular(15.0),
                    color: Colors.redAccent,
                    child: MaterialButton(
                        elevation: 0.0,


                        onPressed: (){
                          Navigator.push(context,
                              MaterialPageRoute(builder: (context) => ChatScreen()));
                        },
                        child: Text('chat')
                    ),
                  ),

                ],
              ),
            ),
          ],
        ),
      ),
    );
    else if(widget.u.type=='doctor')
      return Material(
        child: Container(
          color: Colors.white,
          child: Column(

            children: [
              SizedBox(
                height: 50,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Image.asset(
                    'src/ulogo.jpg',
                    width: 50,
                    height: 70,
                  ),
                  Text(
                    'automatic advice for semest',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  ),
                  Image.asset(
                    'src/flogo.jpg',
                    width: 60,
                    height: 70,
                  ),
                ],
              ),


              ListTile(
                leading: CircleAvatar(

                  radius: 30.0,
                ),
                title: Column(
                  children: [
                    Row(
                      children: [
                        Text('doctor name :'),
                        Text(s['name']),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Text('department:'),
                        Text(s['program']),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),

                    Row(
                      children: [
                        Text('id :'),
                        Text(s['id']),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 50,
              ),

              Row(
                children: [

                  Text('enter student name:',style: TextStyle(fontSize: 15),),

                  Expanded(

                    child: Material(
                      borderRadius: BorderRadius.circular(10.0),
                      color: Colors.white.withOpacity(0.4),
                      elevation: 0.0,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 5.0),
                        child: TextFormField(
                          controller: _StudentNameTextController,
                          decoration: InputDecoration(
                            hintText: "Name",

                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 50,
              ),
              Expanded(
                child: GridView(

                  gridDelegate:SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 200,
                    childAspectRatio: 3/2,
                    crossAxisSpacing: 20,
                    mainAxisSpacing: 20,
                  ),


                  children: [
                    Material(
                      borderRadius: BorderRadius.circular(15.0),
                      color: Colors.redAccent,
                      child: MaterialButton(
                          elevation: 0.0,


                          onPressed: (){
                            Navigator.push(context,
                                MaterialPageRoute(
                                    builder: (context) => MidDgree( 2,name:_StudentNameTextController.text)));
                          },
                          child: Text('show student mid degree')
                      ),
                    ),

                    Material(
                      borderRadius: BorderRadius.circular(15.0),
                      color: Colors.redAccent,
                      child: MaterialButton(
                          elevation: 0.0,


                          onPressed: (){
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) => Record()));

                          },
                          child: Text('show student academic record')
                      ),
                    ),

                    Material(
                      borderRadius: BorderRadius.circular(15.0),
                      color: Colors.redAccent,
                      child: MaterialButton(
                          elevation: 0.0,
                          onPressed: (){
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) => ChatLevels()));

                          },
                          child: Text('chat')
                      ),
                    ),
                    Material(
                      borderRadius: BorderRadius.circular(15.0),
                      color: Colors.redAccent,
                      child: MaterialButton(
                          elevation: 0.0,


                          onPressed: (){
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) => QuestionPost()));
                          },
                          child: Text('post a frequently question ')
                      ),
                    ),
                    Material(
                      borderRadius: BorderRadius.circular(15.0),
                      color: Colors.redAccent,
                      child: MaterialButton(
                          elevation: 0.0,


                          onPressed: (){
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) => QuestionShow()));
                          },
                          child: Text('Show a frequently question ')
                      ),
                    ),


                  ],
                ),
              ),





            ],
          ),
        ),
      );
    else if(widget.u.type=='admin')
      return Material(
        child: Container(
          color: Colors.white,
          child: Column(

            children: [
              SizedBox(
                height: 50,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Image.asset(
                    'src/ulogo.jpg',
                    width: 50,
                    height: 70,
                  ),
                  Text(
                    'automatic advice for semest',
                    style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                  ),
                  Image.asset(
                    'src/flogo.jpg',
                    width: 60,
                    height: 70,
                  ),
                ],
              ),

              ListTile(
                leading: CircleAvatar(

                  radius: 30.0,
                ),
                title: Column(
                  children: [
                    Row(
                      children: [
                        Text('employee name :'),
                        Text(s['name']),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Text('department:'),
                        Text(s['program']),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),

                    Row(
                      children: [
                        Text('id :'),
                        Text(s['id']),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 50,
              ),
              Row(
                children: [

                  Text('enter student name:',style: TextStyle(fontSize: 15),),

                  Expanded(

                    child: Material(
                      borderRadius: BorderRadius.circular(10.0),
                      color: Colors.white.withOpacity(0.4),
                      elevation: 0.0,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 5.0),
                        child: TextFormField(
                          controller: _StudentNameTextController,
                          decoration: InputDecoration(
                            hintText: "Name",

                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              Expanded(

                child: GridView(
                  gridDelegate:SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 200,
                    childAspectRatio: 3/2,
                    crossAxisSpacing: 20,
                    mainAxisSpacing: 20,
                  ),


                  children: [
                    Material(
                      borderRadius: BorderRadius.circular(15.0),
                      color: Colors.redAccent,
                      child: MaterialButton(
                          elevation: 0.0,
                          onPressed: (){
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) => CreateStudent()));

                          },
                          child: Text('add new student')
                      ),
                    ),

                    Material(
                      borderRadius: BorderRadius.circular(15.0),
                      color: Colors.redAccent,
                      child: MaterialButton(
                          elevation: 0.0,
                          onPressed: (){
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) => StudentGrade()));
                          },
                          child: Text('update student final degree ')
                      ),
                    ),

                    Material(
                      borderRadius: BorderRadius.circular(15.0),
                      color: Colors.redAccent,
                      child: MaterialButton(
                          elevation: 0.0,


                          onPressed: (){
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) => MidDgree(1)));
                          },
                          child: Text('update midterm degrees')
                      ),
                    ),


                  ],
                ),
              ),





            ],
          ),
        ),
      );
  }
}
