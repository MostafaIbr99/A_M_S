import 'package:flutter/material.dart';

class MidDgree extends StatefulWidget {
  int type;
  String name;

  MidDgree(this.type, {this.name});

  @override
  _MidDgreeState createState() => _MidDgreeState();
}

class _MidDgreeState extends State<MidDgree> {
  var s = {
    'name': 'mostafa ibrahim',
    'program': 'computer scince',
    'level': '4',
    'id': '145123',
  };

  bool enab = false;

  @override
  Widget build(BuildContext context) {
    if (widget.type == 2 || widget.type == 3)
      return Material(
        child: Column(
          children: [
            SizedBox(
              height: 50,
            ),
            ListTile(
              leading: CircleAvatar(

                radius: 30.0,
              ),
              title: Column(
                children: [
                  Row(
                    children: [
                      Text('student name :'),
                      Text(s['name']),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Text('program:'),
                      Text(s['program']),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Text('level :'),
                      Text(s['level']),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Text('acadmic id :'),
                      Text(s['id']),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Table(border: TableBorder.all(color: Colors.black), children: [
              TableRow(
                children: [
                  Container(
                    color: Colors.black,
                    child: Center(
                        child: Text(
                      ' code :',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    )),
                  ),
                  Container(
                    color: Colors.black,
                    child: Center(
                        child: Text(
                      ' midterm :',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    )),
                  ),
                  Container(
                    color: Colors.black,
                    child: Center(
                        child: Text(
                      ' practical :',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    )),
                  ),
                  Container(
                    color: Colors.black,
                    child: Center(
                        child: Text(
                      ' oral :',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    )),
                  ),
                ],
              ),
            ]),
            for (int i = 0; i < courses.length; i++)
              Table(border: TableBorder.all(color: Colors.black), children: [
                TableRow(children: [
                  Container(
                    height: 30,
                    child: Material(
                      borderRadius: BorderRadius.circular(0.0),
                      color: Colors.white.withOpacity(0.4),
                      elevation: 0.0,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 0.0),
                        child: Text(courses[i]['code']),
                      ),
                    ),
                  ),
                  Container(
                    height: 30,
                    child: Material(
                      borderRadius: BorderRadius.circular(0.0),
                      color: Colors.white.withOpacity(0.4),
                      elevation: 0.0,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 0.0),
                        child: TextFormField(
                          initialValue: courses[i]['mid'].toString(),
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            enabled: enab,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 30,
                    child: Material(
                      borderRadius: BorderRadius.circular(0.0),
                      color: Colors.white.withOpacity(0.4),
                      elevation: 0.0,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 0.0),
                        child: TextFormField(
                          initialValue: courses[i]['pract'].toString(),
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            enabled: enab,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 30,
                    width: 50,
                    child: Container(
                      child: Material(
                        borderRadius: BorderRadius.circular(0.0),
                        color: Colors.white.withOpacity(0.4),
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.only(right: 0.0),
                          child: TextFormField(
                            initialValue: courses[i]['oral'].toString(),
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                              enabled: enab,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ]),
              ]),
          ],
        ),
      );
    if (widget.type == 1)
      return Material(
        child: Column(
          children: [
            SizedBox(
              height: 50,
            ),
            ListTile(
              leading: CircleAvatar(

                radius: 30.0,
              ),
              title: Column(
                children: [
                  Row(
                    children: [
                      Text('student name :'),
                      Text(s['name']),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Text('program:'),
                      Text(s['program']),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Text('level :'),
                      Text(s['level']),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Text('acadmic id :'),
                      Text(s['id']),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 50,
            ),
            Table(border: TableBorder.all(color: Colors.black), children: [
              TableRow(
                children: [
                  Container(
                    color: Colors.black,
                    child: Center(
                        child: Text(
                      ' code :',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    )),
                  ),
                  Container(
                    color: Colors.black,
                    child: Center(
                        child: Text(
                      ' midterm :',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    )),
                  ),
                  Container(
                    color: Colors.black,
                    child: Center(
                        child: Text(
                      ' practical :',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    )),
                  ),
                  Container(
                    color: Colors.black,
                    child: Center(
                        child: Text(
                      ' oral :',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    )),
                  ),
                  Container(
                    color: Colors.black,
                    child: Center(
                        child: Text(
                      ' edit :',
                      style: TextStyle(
                        fontSize: 15,
                        color: Colors.white,
                      ),
                    )),
                  ),
                ],
              ),
            ]),
            for (int i = 0; i < courses.length; i++)
              Table(border: TableBorder.all(color: Colors.black), children: [
                TableRow(children: [
                  Container(
                    height: 30,
                    child: Material(
                      borderRadius: BorderRadius.circular(0.0),
                      color: Colors.white.withOpacity(0.4),
                      elevation: 0.0,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 0.0),
                        child: Text(courses[i]['code']),
                      ),
                    ),
                  ),
                  Container(
                    height: 30,
                    child: Material(
                      borderRadius: BorderRadius.circular(0.0),
                      color: Colors.white.withOpacity(0.4),
                      elevation: 0.0,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 0.0),
                        child: TextFormField(
                          initialValue: courses[i]['mid'].toString(),
                          decoration: InputDecoration(
                            enabled: enab,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 30,
                    child: Material(
                      borderRadius: BorderRadius.circular(0.0),
                      color: Colors.white.withOpacity(0.4),
                      elevation: 0.0,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 0.0),
                        child: TextFormField(
                          initialValue: courses[i]['pract'].toString(),
                          decoration: InputDecoration(
                            enabled: enab,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 30,
                    width: 50,
                    child: Container(
                      child: Material(
                        borderRadius: BorderRadius.circular(0.0),
                        color: Colors.white.withOpacity(0.4),
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.only(right: 0.0),
                          child: TextFormField(
                            initialValue: courses[i]['oral'].toString(),
                            decoration: InputDecoration(
                              enabled: enab,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 30,
                    width: 50,
                    child: Container(
                      child: Material(
                        borderRadius: BorderRadius.circular(0.0),
                        color: Colors.white.withOpacity(0.4),
                        elevation: 0.0,
                        child: Padding(
                          padding: const EdgeInsets.only(right: 0.0),
                          child: IconButton(
                            icon: Icon(Icons.edit),
                            onPressed: () {
                              enab = true;
                            },
                          ),
                        ),
                      ),
                    ),
                  ),
                ]),
              ]),
            Padding(
              padding: const EdgeInsets.fromLTRB(14.0, 8.0, 14.0, 8.0),
              child: Material(
                  borderRadius: BorderRadius.circular(20.0),
                  color: Colors.blue.shade700,
                  elevation: 0.0,
                  child: MaterialButton(
                    onPressed: () {},
                    minWidth: MediaQuery.of(context).size.width,
                    child: Text(
                      "update",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20.0),
                    ),
                  )),
            ),
          ],
        ),
      );
  }

  List courses = [
    {
      'code': 'comp401',
      'mid': 0,
      'pract': 0,
      'oral': 0,
    },
    {
      'code': 'comp403',
      'mid': 0,
      'pract': 0,
      'oral': 0,
    },
    {
      'code': 'comp405',
      'mid': 0,
      'pract': 0,
      'oral': 0,
    },
    {
      'code': 'comp407',
      'mid': 0,
      'pract': 0,
      'oral': 0,
    },
    {
      'code': 'comp409',
      'mid': 0,
      'pract': 0,
      'oral': 0,
    },
    {
      'code': 'comp411',
      'mid': 0,
      'pract': 0,
      'oral': 0,
    },
    {
      'code': 'comp415',
      'mid': 0,
      'pract': 0,
      'oral': 0,
    },
  ];
}
