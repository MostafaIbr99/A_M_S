import 'package:fashion/acadmic_record.dart';
import 'package:fashion/advise_all.dart';
import 'package:fashion/advise_semester.dart';
import 'package:fashion/updata_s_grade.dart';
import 'course_regist.dart';
import 'chat.dart';
import 'creates.dart';


import 'package:flutter/material.dart';

class login extends StatefulWidget {
  @override
  _loginState createState() => _loginState();
}

class _loginState extends State<login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.white,
        child: Column(
          children: [
            SizedBox(
              height: 40,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Image.asset(
                  'src/ulogo.jpg',
                  width: 70,
                  height: 70,
                ),
                Text(
                  'sho2ne',
                  style: TextStyle(fontSize: 20, color: Colors.red),
                ),
                Image.asset(
                  'src/flogo.jpg',
                  width: 80,
                  height: 70,
                ),
              ],
            ),
            FlatButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => login()));
                },
                child: Text('press')),
            FlatButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => RegistPage()));
                },
                child: Icon(Icons.person)),
            FlatButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => login()));
                },
                child: Text('press')),
            FlatButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => ChatList()));
                },
                child: Icon(Icons.person)),
            FlatButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => CreateStudent()));
                },
                child: Icon(Icons.person)),
            FlatButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => StudentGrade()));
                },
                child: Icon(Icons.person)),
            FlatButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => AdviseSemester()));
                },
                child: Icon(Icons.person)),
            FlatButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => AdviseAll()));
                },
                child: Icon(Icons.person)),
            FlatButton(
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Record()));
                },
                child: Icon(Icons.person)),
          ],
        ),
      ),
    );
  }
}
