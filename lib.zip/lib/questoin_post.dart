import 'package:flutter/material.dart';
class QuestionPost extends StatefulWidget {

  @override
  _QuestionPostState createState() => _QuestionPostState();
}

class _QuestionPostState extends State<QuestionPost> {

  TextEditingController _TitleTextController = TextEditingController();
  TextEditingController _BodyTextController = TextEditingController();
  TextEditingController _AnswerTextController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(

      color: Colors.white,
      child: Column(

        children: [
          SizedBox(height: 50,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Image.asset(
                'src/ulogo.jpg',
                width: 50,
                height: 70,
              ),
              Text(
                'automatic advice for semest',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold,color: Colors.black),
              ),
              Image.asset(
                'src/flogo.jpg',
                width: 60,
                height: 70,
              ),
            ],
          ),
          Row(
            children: [
              Text('question title:',style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold,color: Colors.black),),

              Expanded(
                child: Material(
                  borderRadius: BorderRadius.circular(20.0),

                  elevation: 0.0,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 5.0),
                    child: TextFormField(

                      controller: _TitleTextController,
                      decoration: InputDecoration(
                         enabledBorder: OutlineInputBorder(
                         borderSide: BorderSide(width: 2,color: Colors.black),
                               borderRadius: BorderRadius.circular(20),),
                        hintText: "Title",

                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 30,),
          Row(
            children: [
              Text('question body :',style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold,color: Colors.black),),

              Expanded(
                child: Material(
                  borderRadius: BorderRadius.circular(20.0),

                  elevation: 0.0,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 5.0),
                    child: TextFormField(
                      maxLines: 2,

                      controller: _BodyTextController,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(width: 2,color: Colors.black),
                          borderRadius: BorderRadius.circular(20),),
                        hintText: "body",

                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 30,),
          Row(
            children: [
              Text('question answer',style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold,color: Colors.black),),

              Expanded(
                child: Material(
                  borderRadius: BorderRadius.circular(20.0),

                  elevation: 0.0,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 5.0),
                    child: TextFormField(
                      maxLines: 3,

                      controller: _AnswerTextController,
                      decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(width: 2,color: Colors.black),
                          borderRadius: BorderRadius.circular(20),),
                        hintText: "answer",

                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 30,),

          Padding(
            padding: const EdgeInsets.fromLTRB(14.0, 8.0, 14.0, 8.0),
            child: Material(
                borderRadius: BorderRadius.circular(20.0),
                color: Colors.blue.shade700,
                elevation: 0.0,
                child: MaterialButton(
                  onPressed: () {},
                  minWidth: MediaQuery.of(context).size.width,
                  child: Text(
                    "Post",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 20.0),
                  ),
                )),
          ),
        ],
      ),
    );
  }
}
